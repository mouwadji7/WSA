class Employes {
    constructor(employeeID, firstName, lastName, email, phoneNumber) {
        this.employeeID = employeeID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }
}

export default Employes;