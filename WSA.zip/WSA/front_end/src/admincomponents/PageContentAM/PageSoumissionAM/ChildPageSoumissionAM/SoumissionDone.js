import React from 'react';

function SoumissionDone() {
    return (
        <div className="col-sm-6 bg-dark text-white">
        <div className="container pt-5">
            <h1>Listes des soumissions dont le demenagement est pret </h1>
        </div>
    </div>
    );
}


export default SoumissionDone;