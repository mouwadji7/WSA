import React from 'react';

function SoumissionSent() {
    return (
        <div className="col-sm-6 bg-dark text-white">
        <div className="container pt-5">
            <h1>Listes des soumission faites </h1>
        </div>
    </div>
    );
}


export default SoumissionSent;