import React from 'react';

function SoumissionUpdate() {
    return (
        <div className="col-sm-6 bg-dark text-white">
        <div className="container pt-5">
            <h1> Listes des soumissions Traites </h1>
        </div>
    </div>
    );
}


export default SoumissionUpdate;