class Vehicle {
    constructor(vehicleID, brand, model, year) {
        this.vehicleID = vehicleID;
        this.brand = brand;
        this.model = model;
        this.year = year;
    }
}

export default Vehicle;