import React from 'react';

function PrincipalePageAM() {
    return (
        <main className="container-fluid mt-5 pt-5">
            <h1> Page Principales Pour les Admins </h1>

            <div class="mt-4 p-5 bg-primary text-white rounded">
                <p>Pas de news Ajourdhuis</p> 
            </div>

            <div class="mt-4 p-5 bg-primary text-white rounded">
                <p>Pas de taches a faire pour l'instant</p> 
            </div>

            <div class="mt-4 p-5 bg-primary text-white rounded">
                <p>Statitiques de la Semaine </p> 
            </div>

        </main>
    );
}

export default PrincipalePageAM;